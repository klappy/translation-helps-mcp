# T4T

USFM source files for Translation For Translators.

According to the [signed license agreement](https://git.door43.org/Door43/T4T/src/master/T4TSignedLicense.png), this work is available under the terms of a [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) license.