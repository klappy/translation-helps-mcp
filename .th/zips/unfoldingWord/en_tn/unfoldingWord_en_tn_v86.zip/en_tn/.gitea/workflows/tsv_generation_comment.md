Errors are still found in ref: _${REF_NAME}_ 

The commit hash was: _${COMMIT_SHA}_

### Errors:
```json
${ERROR_CONTENT}
```