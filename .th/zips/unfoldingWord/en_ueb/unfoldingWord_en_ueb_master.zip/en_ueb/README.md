# Unlocked English Bible

*an unrestricted English Bible*

This work is based on [The Unlocked Literal Bible](http://ufw.io/ueb/), which is in turn based on the ASV text from 1901.

## Contributors

If you are a contributor to this project please add your name to the `contributor`
field in the [manifest.yaml](https://git.door43.org/Door43/en_ueb/src/master/manifest.yaml)
file.

## Viewing

To view the rendered USFM files, go to https://door43.org/u/Door43/en_ueb/
