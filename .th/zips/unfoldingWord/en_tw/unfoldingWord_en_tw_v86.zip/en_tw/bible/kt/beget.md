# beget, begot, begat, begotten

## Definition:

The term “beget” means to become the father of someone.


## Translation Suggestions:

* You could translate the phrase “beget” as “bring forth” and the term “begat” as “fathered” and the term “begot” as “gave life.”
* The term “begotten” is the passive form of “beget” and means to “be born.”

## Bible References:



## Word Data:

* 