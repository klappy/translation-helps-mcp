# Rimmon

## Facts:

Rimmon was the name of a man and of several places mentioned in the Bible. It was also the name of a false god.

* A man named Rimmon was a Benjamite from the city of Beeroth in Zebulun. This man’s sons murdered Ishbosheth, the crippled son of Jonathan.
* Rimmon was a town in the southern part of Judah, in the region occupied by the tribe of Benjamin.
* The “rock of Rimmon” was a place of safety where the Benjamites went to escape from being killed in a battle.
* Rimmon Perez was an unknown location in the Judean wilderness.
* The Syrian commander Naaman spoke of the temple of the false god Rimmon, where the king of Syria worshiped.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Benjamin](../names/benjamin.md), [Judea](../names/judea.md), [Naaman](../names/naaman.md), [Syria](../names/syria.md), [Zebulun](../names/zebulun.md))

## Bible References:

* [2 Kings 5:18](rc://en/tn/help/2ki/05/18)
* [2 Samuel 4:5-7](rc://en/tn/help/2sa/04/05)
* [Judges 20:45-46](rc://en/tn/help/jdg/20/45)
* [Judges 21:13-15](rc://en/tn/help/jdg/21/13)

## Word Data:

* Strong’s: H7417
