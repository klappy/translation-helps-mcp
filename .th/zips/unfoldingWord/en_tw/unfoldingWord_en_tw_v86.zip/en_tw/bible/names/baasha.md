# Baasha

## Facts:

Baasha was one of Israel’s evil kings, who influenced the Israelites to worship idols.

* Baasha was the third king of Israel and reigned for twenty-four years, during the time when Asa was king of Judah.
* He was a military commander who became king by killing the previous king, Nadab.
* During Baasha’s reign there were many wars between the kingdoms of Israel and Judah, especially with King Asa of Judah.
* Baasha’s many sins caused God to eventually remove him from office by his death.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Asa](../names/asa.md), [false god](../kt/falsegod.md))

## Bible References:

* [1 Kings 15:17](rc://en/tn/help/1ki/15/17)
* [2 Kings 9:9](rc://en/tn/help/2ki/09/09)
* [Jeremiah 41:9](rc://en/tn/help/jer/41/09)

## Word Data:

* Strong’s: H1201
