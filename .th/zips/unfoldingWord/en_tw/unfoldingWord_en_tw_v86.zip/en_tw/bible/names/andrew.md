# Andrew

## Facts:

Andrew was one of twelve men whom Jesus chose to be his closest disciples (later called apostles).

* Andrew’s brother was Simon Peter. Both of them were fishermen.
* Peter and Andrew were fishing in the Sea of Galilee when Jesus called them to be his disciples.
* Before Peter and Andrew met Jesus, they had been disciples of John the Baptizer.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [apostle](../kt/apostle.md), [disciple](../kt/disciple.md), [the twelve](../kt/thetwelve.md))

## Bible References:

* [Acts 1:12-14](rc://en/tn/help/act/01/12)
* [John 1:40](rc://en/tn/help/jhn/01/40)
* [Mark 1:17](rc://en/tn/help/mrk/01/17)
* [Mark 1:29-31](rc://en/tn/help/mrk/01/29)
* [Mark 3:17-19](rc://en/tn/help/mrk/03/17)
* [Matthew 4:19](rc://en/tn/help/mat/04/19)
* [Matthew 10:2-4](rc://en/tn/help/mat/10/02)

## Word Data:

* Strong’s: G04060
