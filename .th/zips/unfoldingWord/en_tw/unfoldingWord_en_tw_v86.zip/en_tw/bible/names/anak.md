# Anak, Anakites

## Facts:

Anak is the name of a man whose father was Arba and whose descendents were called “Anakites” or “the Anakim” or “the Anak.” 

* The Anakites were a very tall people.
* The Anakites are a people group who lived in the land that Yahweh promised to give to the Israelites. The Israelites eventually conquered and dispossessed them.
* Anak had three sons or descendants who were named Ahiman, Sheshai, and Talmai.
* The name “Anak” is an English transliteration of the Hebrew word for Anak.

(See also: [Hebron](../names/hebron.md))

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))


## Bible References:



## Word Data:

* Strong’s: 
