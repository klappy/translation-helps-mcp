# Nahor

## Facts:

Nahor was the name of two relatives of Abraham, his grandfather and his brother.

* Abraham’s brother Nahor was the grandfather of Isaac’s wife Rebekah.
* The phrase “city of Nahor” could mean “the city named Nahor” or “the city where Nahor had lived” or “Nahor’s city.”

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Abraham](../names/abraham.md), [Rebekah](../names/rebekah.md))

## Bible References:

* [1 Chronicles 1:24-27](rc://en/tn/help/1ch/01/24)
* [Genesis 31:53](rc://en/tn/help/gen/31/53)
* [Joshua 24:2](rc://en/tn/help/jos/24/02)
* [Luke 3:34](rc://en/tn/help/luk/03/34)

## Word Data:

* Strong’s: H5152, G34930
