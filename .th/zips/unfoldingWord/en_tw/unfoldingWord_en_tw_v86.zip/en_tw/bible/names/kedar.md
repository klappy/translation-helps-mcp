# Kedar

## Facts:

Kedar was Ishmael’s second son. It was also an important city, which was probably named after the man.

* The city of Kedar is located in the northern part of Arabia near the southern border of Palestine. In Bible times, it was known for its greatness and beauty.
* The descendants of Kedar formed a large people group that is also called “Kedar.”
* The phrase “dark tents of Kedar” refers to the black goathair tents the people of Kedar lived in.
* These people raised sheep and goats. They also used camels for transporting things.
* In the Bible, the phrase “the glory of Kedar” refers to the greatness of that city and its people.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Arabia](../names/arabia.md), [goat](../other/goat.md), [Ishmael](../names/ishmael.md), [sacrifice](../other/sacrifice.md))

## Bible References:

* [Song of Songs 1:5](rc://en/tn/help/sng/01/05)

## Word Data:

* Strong’s: H6938
