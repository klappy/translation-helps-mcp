# Rapha, Raphaites, Raphaim

## Facts:

The term “Rapha” is the name for a group of inhabitants who lived in a location on the Eastern side of the Jordan river. The “Rapha” are called “Raphaites” or “Raphaim”

* There was a valley named after this people group, “the valley of the Rephaites,” which is mentioned six times in the Old Testament.
* “Rapha” is an English transliteration of a Hebrew word. It is difficult to determine with certainty what the word “Rapha” means, and consequently, what type of beings the word “Rapha” refers to. The term “Rapha” could refer to a group of living people, spirits, or quasi-divine beings. For this reason many English translations have chosen to transliterate the original language (Hebrew) word as “Raphaites” or “Raphaim.” You may desire to do the same thing in your translation.
* The people group the Ammonites called the Raphaites by the name “Zamzummites” (See Deuteronomy 2:20).

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names), [Copy or Borrow Words](rc://en/ta/man/translate/translate-transliterate))


## Bible References:


## Word Data:

* Strong’s:

