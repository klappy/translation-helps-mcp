# Meshech

## Facts:

Meshech is the name of two men in the Old Testament.

* One Meshech was a son of Japheth.
* The other Meshech was a grandson of Shem.
* Meshech was also the name of a region of land, which was probably named after one of these men.
* The region of Meshech may have been located in part of what is now the country of Turkey.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Japheth](../names/japheth.md), [Noah](../names/noah.md), [Shem](../names/shem.md))

## Bible References:

* [1 Chronicles 1:5-7](rc://en/tn/help/1ch/01/05)
* [Ezekiel 27:12-13](rc://en/tn/help/ezk/27/12)
* [Genesis 10:2-5](rc://en/tn/help/gen/10/02)
* [Psalms 120:5](rc://en/tn/help/psa/120/05)

## Word Data:

* Strong’s: H4851, H4902
