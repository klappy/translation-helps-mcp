# Geshur, Geshurites

## Definition:

During the time of King David, Geshur was a small kingdom located on the east side of the Sea of Galilee between the countries of Israel and Aram.

* King David married Maacah, the daughter of Geshur’s king, and she bore him a son, Absalom.
* After murdering his half-brother Amnon, Absalom fled northeast from Jerusalem to Geshur, a distance of about 140 kilometers. He stayed there three years.

(See also: [Absalom](../names/absalom.md), [Amnon](../names/amnon.md), [Aram](../names/aram.md), [Sea of Galilee](../names/seaofgalilee.md))

## Bible References:

* [1 Chronicles 2:23](rc://en/tn/help/1ch/02/23)
* [2 Samuel 3:2-3](rc://en/tn/help/2sa/03/02)
* [Deuteronomy 3:14](rc://en/tn/help/deu/03/14)
* [Joshua 12:3-5](rc://en/tn/help/jos/12/03)

## Word Data:

* Strong’s: H1650
