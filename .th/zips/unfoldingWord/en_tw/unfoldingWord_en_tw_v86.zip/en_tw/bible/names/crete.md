# Crete, Cretan

## Facts:

Crete is an island that is located off the southern coast of Greece. A “Cretan” is someone who lives on this island.

* The apostle Paul traveled to the island of Crete during his missionary journeys.
* Paul left his co-worker Titus on Crete to teach the Christians and to help appoint leaders for the church there.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

## Bible References:

* [Acts 2:11](rc://en/tn/help/act/02/11)
* [Acts 27:8](rc://en/tn/help/act/27/08)
* [Amos 9:7-8](rc://en/tn/help/amo/09/07)
* [Titus 1:12](rc://en/tn/help/tit/01/12)

## Word Data:

* Strong’s: G29120, G29140
