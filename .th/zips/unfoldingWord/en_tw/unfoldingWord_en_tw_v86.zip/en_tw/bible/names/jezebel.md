# Jezebel

## Facts:

Jezebel was the wicked wife of King Ahab of Israel.

* Jezebel influenced Ahab and the rest of Israel to worship idols.
* She also killed many of God’s prophets.
* Jezebel caused an innocent man named Naboth to be killed so that Ahab could steal Naboth’s vineyard.
* Jezebel was finally killed due to all the evil things she had done. Elijah prophesied about how she would die and it happened exactly as he had predicted.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Ahab](../names/ahab.md), [Elijah](../names/elijah.md), [false god](../kt/falsegod.md))

## Bible References:

* [1 Kings 16:31-33](rc://en/tn/help/1ki/16/31)
* [1 Kings 19:1-3](rc://en/tn/help/1ki/19/01)
* [2 Kings 9:7](rc://en/tn/help/2ki/09/07)
* [2 Kings 9:31](rc://en/tn/help/2ki/09/31)
* [Revelation 2:20](rc://en/tn/help/rev/02/20)

## Word Data:

* Strong’s: H0348, G24030
