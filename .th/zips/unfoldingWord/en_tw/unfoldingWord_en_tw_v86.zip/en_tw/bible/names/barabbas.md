# Barabbas

## Facts:

Barabbas was a prisoner in Jerusalem at the time when Jesus was arrested.

* Barabbas was a criminal who had committed crimes of murder and rebellion against the Roman government.
* When Pontius Pilate offered to either release Barabbas or Jesus, the people chose Barabbas.
* So Pilate allowed Barabbas to go free, but condemned Jesus to be killed.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Pilate](../names/pilate.md), [Rome](../names/rome.md))

## Bible References:

* [John 18:40](rc://en/tn/help/jhn/18/40)
* [Luke 23:19](rc://en/tn/help/luk/23/19)
* [Mark 15:7](rc://en/tn/help/mrk/15/07)
* [Matthew 27:15-16](rc://en/tn/help/mat/27/15)

## Word Data:

* Strong’s: G09120
