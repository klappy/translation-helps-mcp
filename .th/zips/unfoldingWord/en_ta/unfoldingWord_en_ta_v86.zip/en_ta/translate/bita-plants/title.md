Biblical Imagery — Plants
