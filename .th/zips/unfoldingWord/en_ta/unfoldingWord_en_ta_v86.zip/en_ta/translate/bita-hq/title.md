Biblical Imagery — Body Parts and Human Qualities
