Biblical Imagery — Animals
