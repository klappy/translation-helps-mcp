Biblical Imagery — Extended Metaphors
