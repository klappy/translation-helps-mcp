Connect — Contrary to Fact Conditions
