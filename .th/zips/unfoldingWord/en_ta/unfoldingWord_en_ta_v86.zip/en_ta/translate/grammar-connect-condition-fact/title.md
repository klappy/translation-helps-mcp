Connect — Factual Conditions
