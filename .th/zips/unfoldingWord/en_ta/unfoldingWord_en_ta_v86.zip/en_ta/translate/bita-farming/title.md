Biblical Imagery — Farming
